const contactForm = document.querySelector(".contact-form");
const footerText = document.querySelector(".footer-text");

contactForm.addEventListener("submit", (e) => {
  e.preventDefault();
});

footerText.innerHTML = `Made by <span style="color: #737373">Mick Manuit ${new Date().getFullYear()}`;
